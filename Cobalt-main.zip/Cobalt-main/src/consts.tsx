const obfuscation = true;
// @ts-ignore
const bareServerURL = new URL("/bare/", globalThis.location);
const github = "https://github.com/cognetwork-dev/Cobalt";
const discord = "https://discord.com/invite/yk33HZSZkU";

export { obfuscation, bareServerURL, github, discord };
